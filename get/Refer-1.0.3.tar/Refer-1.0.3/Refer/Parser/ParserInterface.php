<?php

namespace Refer\Parser;

interface ParserInterface {

	public function parse($content);

}

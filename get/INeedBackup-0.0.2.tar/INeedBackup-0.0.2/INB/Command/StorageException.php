<?php

class INB_Command_StorageException extends InvalidArgumentException {}
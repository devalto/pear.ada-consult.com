<?php

class INB_Command_ConfigurationException extends InvalidArgumentException {}
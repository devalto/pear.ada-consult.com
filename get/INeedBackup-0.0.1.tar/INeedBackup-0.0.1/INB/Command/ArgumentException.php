<?php

class INB_Command_ArgumentException extends InvalidArgumentException {}